package com.dropzone.friend.entity;

public enum FriendShipStatus {
    WAITTING, ACCEPT
}
