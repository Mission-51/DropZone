package com.dropzone.friend.dto;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class FriendReponseDto {
    private String message;
}
