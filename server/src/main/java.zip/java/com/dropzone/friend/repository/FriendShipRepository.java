package com.dropzone.friend.repository;

import com.dropzone.friend.entity.FriendShipEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FriendShipRepository extends JpaRepository<FriendShipEntity, Long> {

}
