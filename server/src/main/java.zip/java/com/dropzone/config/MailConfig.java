package com.dropzone.config;

public class MailConfig {

}
