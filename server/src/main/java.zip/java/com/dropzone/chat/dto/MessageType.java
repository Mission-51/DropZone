package com.dropzone.chat.dto;

public enum MessageType {
    ENTER,
    CHAT,
    LEAVE,
}
